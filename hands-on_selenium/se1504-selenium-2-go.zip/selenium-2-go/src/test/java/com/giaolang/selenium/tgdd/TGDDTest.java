/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.giaolang.selenium.tgdd;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author giao.lang
 */
public class TGDDTest {
    
    private static WebDriver myBrowser;
    
    @BeforeAll //khởi động browser, vào trang luôn
    public static void setUpClass() {
        String driverPath = "chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", driverPath);
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        
        myBrowser = new ChromeDriver(opt);
        
        myBrowser.manage().window().maximize(); //bung full màn hình
        myBrowser.get("https://thegioididong.com");
        
        //ta phải tắt luôn cái popup hỏi Location
        WebElement locationPopup = myBrowser.findElement(By.xpath("//*[@id=\"lc_pop--sugg\"]/div/div[2]/a[2]"));
        locationPopup.click();
        
    }
    
    @AfterAll  //đóng browser sau khi xong các test cases
    public static void tearDownClass() {
        myBrowser.quit();
    }
    
   
    
    @Test
    public void verifyPhonePriceGivenAPhoneReturnsTheSamePriceBothInBriefAndDetailsPage() throws InterruptedException {
        //search trước một mẫu điện thoại
        
        WebElement searchBox = myBrowser.findElement(By.xpath("//input[@id='skw']"));
        searchBox.sendKeys("samsung");
        Thread.sleep(3000);        
        searchBox.submit();

        
        //tìm điện thoại đầu tiên, lấy giá tiền
        WebElement phoneBriefE = myBrowser.findElement(By.xpath("//aside[@class='left_search']//li[7]//a"));
        //String phoneDesc = phoneBriefE.getText();
        //System.out.println("phone #1: " + phoneDesc);
                
        //tìm sâu bên trong 1 tag có đc tag nào khác
        //ko sợ lộn với giá thằng đt kế bên
        WebElement priceBriefE = phoneBriefE.findElement(By.className("price"));
        String priceBrief = priceBriefE.getText();
        System.out.println("Price: " + priceBrief);
        phoneBriefE.click();
        
    }
    
 
}
