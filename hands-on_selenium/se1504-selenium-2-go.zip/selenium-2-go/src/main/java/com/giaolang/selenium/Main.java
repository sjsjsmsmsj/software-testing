/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.giaolang.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author giao.lang
 */
public class Main {
    
    public static void main(String[] args) throws InterruptedException {
        //testGoogleWithAGivenKeyword();
        //testGoogleInIncognitoMode();
        testLoginWithAValidAccountReturnsWelcomeMessage();
    }
    
    //gọi thử Google lên coi được ko, sau đó search thử 1 keyword
    //Test Case #1
    //Description: check search function of Google with a keyword
    //Preconditions:
    //   data (keyword): Trò chơi con mực
   
    //Steps:
    //   1. Open a certain browser, e.g. Chrome
    //   2. Type url: https://google.com
    //   3. Type keyword: Trò chơi con mực
    //   4. Hit enter
    
    //Expected results:
    //   List of hyperlinks contain "Trò chơi con mực" keyword
    
    public static void testGoogleWithAGivenKeyword() {
        String driverPath = "chromedriver.exe"; //tìm ngay trong thư mục project
        //nếu ai để .exe này ở nơi khác, thì phải gõ đủ path
        //  "D:\\swt\\project\\chromedriver.exe"
        
        System.setProperty("webdriver.chrome.driver", driverPath);
        //báo máy ảo Java JVM biết có 1 biến môi trường tên là "..."
        //trỏ value là chromedriver.exe
        
        //trình duyệt đc xem là 1 object, tạo object trình duyệt 
        //trỏ thẳng vào Chrome vật lí
        WebDriver myBrowser = new ChromeDriver();
                              //trình duyệt mới xh, chrome cũ đang mở kệ
        //default mở 1/2 bề rộng Desktop
        myBrowser.manage().window().maximize(); //bung full màn hình
        myBrowser.get("https://google.com");
        
    }

    public static void testGoogleInIncognitoMode() throws InterruptedException {
        String driverPath = "chromedriver.exe"; //tìm ngay trong thư mục project
        //nếu ai để .exe này ở nơi khác, thì phải gõ đủ path
        //  "D:\\swt\\project\\chromedriver.exe"
        
        System.setProperty("webdriver.chrome.driver", driverPath);
        //báo máy ảo Java JVM biết có 1 biến môi trường tên là "..."
        //trỏ value là chromedriver.exe
        
        //trình duyệt đc xem là 1 object, tạo object trình duyệt 
        //trỏ thẳng vào Chrome vật lí
        
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        
        //opt.addArguments("--lang=en-GB");
        
        WebDriver myBrowser = new ChromeDriver(opt);
                              //trình duyệt mới xh, chrome cũ đang mở kệ
        //default mở 1/2 bề rộng Desktop
        myBrowser.manage().window().maximize(); //bung full màn hình
        myBrowser.get("https://google.com");
        
        //tìm ô search, tag <input>
        //mọi thẻ ở trong trang web đều là 1 object, thẻ có thể chứa thẻ
        //trong object thì có biến object khác, Book thì có Author
        //mọi thẻ trong trang web dều thuộc class WebElement
        //myBrowser dang nắm toàn bộ các object trong trang web, nhờ
        //nó tìm giùm các obj/tag theo SELECTOR dc chỉ ra
        //WebElement searchBox = myBrowser.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input"));
        //WebElement searchBox = myBrowser.findElement(By.xpath("//input[@title='Tìm kiếm']"));
        WebElement searchBox = myBrowser.findElement(By.name("q"));
        searchBox.sendKeys("Trò chơi con mực"); //gõ vào ô text
        
        Thread.sleep(3000); //dừng app lại 3 giây
        searchBox.submit(); //vì ô nhập nằm trong form
                            //tương dương nhấn enter nút submit
    }
    
    //Test case #2: Check login of PHPTravels with a valid account...
    //...
    //...
    public static void testLoginWithAValidAccountReturnsWelcomeMessage() throws InterruptedException {
        String driverPath = "chromedriver.exe"; //tìm ngay trong thư mục project
        //nếu ai để .exe này ở nơi khác, thì phải gõ đủ path
        //  "D:\\swt\\project\\chromedriver.exe"
        
        System.setProperty("webdriver.chrome.driver", driverPath);
        //báo máy ảo Java JVM biết có 1 biến môi trường tên là "..."
        //trỏ value là chromedriver.exe
        
        //trình duyệt đc xem là 1 object, tạo object trình duyệt 
        //trỏ thẳng vào Chrome vật lí
        
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        
        //opt.addArguments("--lang=en-GB");
        
        WebDriver myBrowser = new ChromeDriver(opt);
                              //trình duyệt mới xh, chrome cũ đang mở kệ
        //default mở 1/2 bề rộng Desktop
        myBrowser.manage().window().maximize(); //bung full màn hình
        myBrowser.get("https://www.demo.guru99.com/V4/index.php");
        
        WebElement username = myBrowser.findElement(By.name("uid"));
        username.sendKeys("mngr361652"); //gõ vào ô text
        
        WebElement pass = myBrowser.findElement(By.cssSelector("input[name='password']"));
        pass.sendKeys("ujYzEte"); //gõ vào ô text
               
        Thread.sleep(3000); //dừng app lại 3 giây
        
        WebElement loginBtn = myBrowser.findElement(By.xpath("//input[@name='btnLogin']"));
        loginBtn.submit();
        
        //KHI CHUYỂN TRANG, LƯU Ý 1 ĐIỀU QUAN TRỌNG
        //TRANG CÓ THỂ TẢI VỀ TỪNG PHẦN, RENDER TỪ TỪ
        //LOAD CHẬM DO LÍ DO KHÁCH QUAN MẠNG CHẬM, CHỦ QUAN APP CHẬM
        //VIỆC TRÌNH DUYỆT TẢI TRANG VỀ VÀ CODE CỦA MÌNH 2 THỨ BẤT 
        //ĐỒNG BỘ
        //LỆNH SELENIUM THỰC THI NHANH HƠN TRANG ĐC TẢI VỀ 
        //trang welcome chưa về mà mình đã đi tìm TAG
        //SOLUTION: WAIT (2 loại wait - implicit & explicit)
        
        Thread.sleep(3000); //chủ động nghỉ 3s rồi tính
        WebElement welcomeMsg = myBrowser.findElement(By.cssSelector("tr[class='heading3'] td"));
        System.out.println("Welcome msg: " + welcomeMsg.getText());
        
        //lấy data các trang web qua Selenium + xPath dịnh vị thẻ
        //CRAWLER BOT CÀO DATA
        //CÀY VIEW CHO SẾP
    }
}


