/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.giaolang.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 *
 * @author giao.lang
 */
public class Selenium2Go {

    public static void main(String[] args) throws InterruptedException {
        searchGoogleV2();
    }
    
    public static void searchGoogleV2() throws InterruptedException {
        //1. Khai báo biến đại diện/trỏ đến trình duyệt sẽ đc mở/đc new
        WebDriver myBrowser;  //biến object thuộc bộ thư viện Selenium
                              //thằng này sẽ trỏ đến cái trình duyệt khi đc new 
                              //mỗi lần new là 1 trình duyệt đc mở ra, 1 vùng đc cấp
                              //1 object Trình Duyệt đc new trong HEAP
        //2. Khai báo người em song sinh, gã sẽ điều khiển trình duyệt 
        //   nó luôn đc phát hành song song với phiên bản trình duyệt mà bá tánh xài
        //   tương thích version với trình duyệt đang xài!!! BẮT BUỘC!!!
        //   WebDriver là tên gọi của người anh em song sinh, là file .exe/.dll  
        String driverPath = "chromedriver.exe";
                
        //3. new Trình Duyệt (mở trình duyệt) gắn kết với người em song sinh
        System.setProperty("webdriver.chrome.driver", driverPath);
        //giải thích: báo với máy ảo Java rằng, có 1 thằng .exe muốn tham gia vào 
        //danh sách class mà JVM quản lí.
        //.EXE .DLL, xả 1 đống class điều khiển trình duyệt vào trong JVM lúc run-time
        //và gọi nhóm class này là webdriver.chrome.driver -> hằng số quy ước sẵn rồi
        //code Selenium qua class WebDriver, ChromeDriver sẽ xài ở dưới đây
        //biết cách chơi với các class của .exe vừa rồi, vì chúng đang cùng ở trong máy ảo
                
        ChromeOptions opt = new ChromeOptions();
        opt.addArguments("--incognito");
        opt.addArguments("--lang=zh-cn");  //=vi tiếng Việt;  en-GB: tiếng Anh; =zh-cn: tiếng Hoa
        
        myBrowser = new ChromeDriver(opt);
        
        //4. Viết code dùng Selenium nói chuyện với người song sinh - driver
        //   driver biết cách nói chuyện với trình duyệt thật đã new!!!
        //   trình duyệt sẵn sàng thông qua người em đưa hết data (trang web trong ram)
        //   cho mình dưới dạng cây DOM - Document Object Model
        //   trang HTML trả về trong RAM của trình duyệt đc xem là 1 cây các object
        //   node/tag đc xem là 1 object thuộc nhóm WebElement
        
        myBrowser.get("https://google.com");  //duyệt trang trên object trình duyệt vừa new
        
        myBrowser.manage().window().maximize();
      
        Thread.sleep(3000);  //app nghỉ 3s rồi chạy tiếp lệnh sau
        
        myBrowser.quit();
        
    }
    
    public static void searchGoogle() {
        //1. Khai báo biến đại diện/trỏ đến trình duyệt sẽ đc mở/đc new
        WebDriver myBrowser;  //biến object thuộc bộ thư viện Selenium
                              //thằng này sẽ trỏ đến cái trình duyệt khi đc new 
                              //mỗi lần new là 1 trình duyệt đc mở ra, 1 vùng đc cấp
                              //1 object Trình Duyệt đc new trong HEAP
        //2. Khai báo người em song sinh, gã sẽ điều khiển trình duyệt 
        //   nó luôn đc phát hành song song với phiên bản trình duyệt mà bá tánh xài
        //   tương thích version với trình duyệt đang xài!!! BẮT BUỘC!!!
        //   WebDriver là tên gọi của người anh em song sinh, là file .exe/.dll  
        String driverPath = "chromedriver.exe";
                
        //3. new Trình Duyệt (mở trình duyệt) gắn kết với người em song sinh
        System.setProperty("webdriver.chrome.driver", driverPath);
        //giải thích: báo với máy ảo Java rằng, có 1 thằng .exe muốn tham gia vào 
        //danh sách class mà JVM quản lí.
        //.EXE .DLL, xả 1 đống class điều khiển trình duyệt vào trong JVM lúc run-time
        //và gọi nhóm class này là webdriver.chrome.driver -> hằng số quy ước sẵn rồi
        //code Selenium qua class WebDriver, ChromeDriver sẽ xài ở dưới đây
        //biết cách chơi với các class của .exe vừa rồi, vì chúng đang cùng ở trong máy ảo
                
        myBrowser = new ChromeDriver();
        
        //4. Viết code dùng Selenium nói chuyện với người song sinh - driver
        //   driver biết cách nói chuyện với trình duyệt thật đã new!!!
        //   trình duyệt sẵn sàng thông qua người em đưa hết data (trang web trong ram)
        //   cho mình dưới dạng cây DOM - Document Object Model
        //   trang HTML trả về trong RAM của trình duyệt đc xem là 1 cây các object
        //   node/tag đc xem là 1 object thuộc nhóm WebElement
        
        myBrowser.get("https://google.com");  //duyệt trang trên object trình duyệt vừa new
        
        myBrowser.manage().window().maximize();
        
        //ta sẽ đi tìm các tag, và hành xử trên các thẻ. Các thẻ này là object
        //nằm trong object bự là my Browser (là field/đặc tính của object bự)
        WebElement searchBox = myBrowser.findElement(By.name("q"));
        //lấy đc ô search dưới dạng object
        searchBox.sendKeys("ÉT Ô ÉT");
        searchBox.submit();
        
                              
    }
}
